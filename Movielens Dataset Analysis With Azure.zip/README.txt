README:

I DID THIS WORK SAMPLE PROJECT BASED ON THE MOVIELENS DATASET, THE CSV DOCUMENTS FOR WHICH ARE ENCLOSED WITH THIS DELIVERABLE.


ITEMS ENCLOSED:

- MOVIELENS DATASET LABELED: ml-latest-small. This contains the entire dataset.

- AUTHORIZATION.IPYNB*

- ALGORITHM.IPYNB**

- SCREENSHOT OF MY AZURE PAGE WHERE I WORKED ON THIS PROJECT

- RATINGS YEAR VISUALIZATION

- EXCEL SHEET RESULTS FOR RECOMMENDED ROWS THROUGH COLLABORATIVE FILTERING




*My code which enabled me to connect to Azure Data Lake Storage, access documents in the correct container, and create needed mount points.

**My code which enabled me to read in all the datasets appropriately, conduct exploratory data analysis, wrangle with the data, create visualizations and then make a movie recommendation system based on collaborative filtering.